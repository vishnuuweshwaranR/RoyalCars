# react-nodejs-eb
Example project on how to deploy react with nodejs project on Elastic Beanstalk environment
